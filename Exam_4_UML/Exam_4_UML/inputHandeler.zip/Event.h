#pragma once
class Event
{
public:
	int key;
};

