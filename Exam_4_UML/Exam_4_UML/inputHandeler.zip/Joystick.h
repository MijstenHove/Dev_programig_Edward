#pragma once
#include "Controller.h"
class Joystick : Controller
{
public:

};

